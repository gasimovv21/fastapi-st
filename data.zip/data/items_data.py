items = [
    {
        "id": 1,
        "name": "Asus Tuf Dash F15",
        "price": 4200.0,
    },
    {
        "id": 2,
        "name": "Macbook Pro 16",
        "price": 10000.0,
    },
    {
        "id": 3,
        "name": "Lenovo Legion 5",
        "price": 3500.0,
    },
    {
        "id": 4,
        "name": "Dell XPS 13",
        "price": 5000.0,
    },
    {
        "id": 5,
        "name": "HP Spectre x360",
        "price": 6000.0,
    },
    {
        "id": 6,
        "name": "Acer Swift 3",
        "price": 3000.0,
    },
    {
        "id": 7,
        "name": "Razer Blade Stealth",
        "price": 8000.0,
    },
    {
        "id": 8,
        "name": "Microsoft Surface Laptop 4",
        "price": 7000.0,
    },
    {
        "id": 9,
        "name": "Samsung Galaxy Book Pro",
        "price": 4000.0,
    },
    {
        "id": 10,
        "name": "LG Gram 17",
        "price": 9000.0,
    },
]